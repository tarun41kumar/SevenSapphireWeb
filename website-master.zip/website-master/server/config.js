const nodemailer = require('nodemailer');
const dotenv = require('dotenv')
dotenv.config();

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: "jansanshiv@gmail.com", // your email address to send email from
    pass: "8824318868"// your gmail account password
  }
});

module.exports = transporter;