import React from 'react'
import MainGallery from '../Components/MainGallery'

const Gallery = () => {
    return (
        <>
            <h1 className="mainHeading my-4 text-center mx-auto">Photography</h1>
            <hr className="mx-auto mainHr" />
            {/* <MainGallery /> */}

        </>
    )
}

export default Gallery