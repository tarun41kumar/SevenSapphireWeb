import React from "react";
import Slider from '../Components/HomeImageSlider'
import Contact from '../Components/Contact'
import Service from '../Components/Service'
import Gallery from '../Components/HomeGallery'
import PrimeServices from '../Components/PrimeServices'
import Swiper2 from '../Service/Swiper2/Swiper'
// import UpcomingEvents from '../Components/UpcomingEvents'
// import { NavLink } from "react-router-dom";


const Home = () => {

  

  return (
    <>
   <div id="floatingevents" className="position-fixed GeneralText">
    {/* <NavLink to="/events"><span>Events</span></NavLink> */}
    <a href='https://forms.gle/Lh19fMuhrxbpVELn9' target="_blank" rel="noreferrer"><span>Register Now</span></a>
    </div>
    {/* <UpcomingEvents/> */}
    <Slider />
    <Service />
    <PrimeServices/>
    <Gallery />
    <h1 className="mainHeading text-center mt-4">Our Eminent Artist</h1>
    <hr className="mainHr mx-auto"/>
    <Swiper2 />
    <Contact />
    

    </>
  );
}

export default Home;