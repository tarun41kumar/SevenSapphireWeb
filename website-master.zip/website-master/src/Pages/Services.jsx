import React from 'react';
import { homeServices } from '../Constant'
import { NavLink } from 'react-router-dom'
const Services = () => {
	const inner_html = []
	for (const [i, d] of homeServices.entries()) {
		inner_html.push(
			<NavLink to={d.goto}>
				<section
					className='Service_bg vh-100 w-100 position-sticky sticky-top py-5'
					style={{
						backgroundImage: `url(${d.image})`, backgroundSize: 'cover',
						backgroundPosition: 'center center',
						backgroundRepeat: 'no-repeat',
						zIndex: 3 * i + 1
					}}>
					<h1 className="pt-5 text-center mt-5 mainHeading text-light font-weight-bold">{d.name}</h1>
					<hr className="mainHr mx-auto" />
				</section>
			</NavLink>
		)
	}
	return (
		<>
			<div id='Service_page'>
				{inner_html}
			</div>
		</>
	);
};
export default Services;