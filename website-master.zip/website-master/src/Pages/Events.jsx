import React from 'react'

const Events = () => {
    return (
        <>
            <div className="container">
                <div className="row w-100 m-0 p-0">
                    <img className="col-lg-6 p-1 w-100" src="https://all-about-images.s3.us-east-2.amazonaws.com/Images/wintercamp.jpg" alt="" />
                    <img className="col-lg-6 p-1 w-100" src="https://all-about-images.s3.us-east-2.amazonaws.com/Images/summercamp.jpg" alt="" />
                </div>
            </div>
        </>
    )
}
export default Events