import React from 'react';
// import ArtContract from '../Service/ArtContract'
// import Dance from '../Service/Dance'
// import Demo from '../Service/Demo'
const Gift = () => {
  return (
    <>
      <div>
          <h1 className="text-center">  Wait Gifts are On The Way!!!</h1>
          {/* <ArtContract /> */}
          {/* <Dance /> */}
          {/* <Demo /> */}
      </div>
    </>
  );
}

export default Gift;