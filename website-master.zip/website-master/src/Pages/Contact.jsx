import React from 'react';
import CompContact from '../Components/Contact'
const Contact = () => {
  return (
    <>
      <CompContact />
    </>
  );
}

export default Contact;