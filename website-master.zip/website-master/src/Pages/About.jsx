import React from 'react';
import CompAbout  from '../Components/About'
import Contact from '../Components/Contact'
import Team from '../Components/Team'

const About = () => {
  return (
    <>
      <CompAbout />
      <Team />
      <Contact />
    </>
  );
}

export default About;