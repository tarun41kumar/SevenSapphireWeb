import React from 'react';
import "tailwindcss/dist/base.css";
import {Switch, Route, Redirect } from 'react-router-dom'
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../node_modules/bootstrap/dist/js/bootstrap.bundle';
import '../node_modules/jquery/dist/jquery'
import Navbar from './Components/Navbar'
import FloatingLogo from './Components/Floating_icon'
import ComingSoon from './Components/ComingSoon'
import Home from './Pages/Home';
import About from './Pages/About'
import Services from './Pages/Services'
import Error404 from './Pages/Error404'
import Contact from './Pages/Contact'
import Footer from './Components/Footer'
import ArtContract from './Service/ArtContract'
import Design from './Service/Architect'
import Ocassion from './Service/Occasion'
import { ArtContractSubParts} from '../src/Constant'
import Subservice1 from '../src/Service/SubService1'
import Subservice2 from '../src/Service/SubService2'
import Events from '../src/Pages/Events'
import ScrollToTop from '../src/Components/ScrollToTop'
import "./style.css"




function App() {
  return (
    <>
      <div>
      <ScrollToTop />
        <Navbar />
        <FloatingLogo/>
        <Switch>
          <Route exact path= '/' component={Home} />
          <Route exact path='/about' component={About} />
          <Route exact path='/events' component={Events} />
          <Route exact path='/contact' component={Contact} />
          {/* <Route exact path='/photography' component={Gallery} /> */}
          {/* <Route exact path='/gifts' component={Gift} /> */}
          <Route exact path='/comingsoon' component={ComingSoon} />
          <Route exact path='/services' component={Services} />
          <Route exact path='/services/wedding' component={ComingSoon} />
          <Route exact path='/services/artcontract' component={ArtContract} />
          <Route exact path='/services/occassion' component={Ocassion} />
          <Route exact path='/services/design' component={Design} />
          <Route exact path='/services/artcontract/portrait' render={(props) => ( <Subservice2 {...ArtContractSubParts.Portrait} isAuthed={true} /> )}/>
          <Route exact path='/services/artcontract/tattoo' render={(props) => ( <Subservice2 {...ArtContractSubParts.Tattoo} isAuthed={true} /> )}/>
          <Route exact path='/services/artcontract/sculpture' render={(props) => ( <Subservice1 {...ArtContractSubParts.Sculpture} isAuthed={true} /> )}/>
          <Route exact path='/services/artcontract/rangoli' render={(props) => ( <Subservice1 {...ArtContractSubParts.Rangoli} isAuthed={true} /> )}/>
          <Route exact path='/services/artcontract/wallpainting' render={(props) => ( <Subservice1 {...ArtContractSubParts.WallPainting} isAuthed={true} /> )}/>
          <Route exact path='/services/artcontract/landscape' render={(props) => ( <Subservice1 {...ArtContractSubParts.Landscape} isAuthed={true} /> )}/>
          <Route exact path='/services/design/architect' render={(props) => ( <Subservice1 {...ArtContractSubParts.Architect} isAuthed={true} /> )}/>
          <Route exact path='/services/design/interior' render={(props) => ( <Subservice1 {...ArtContractSubParts.Interior} isAuthed={true} /> )}/>
          <Route exact path='/services/occassion/band' render={(props) => ( <Subservice1 {...ArtContractSubParts.Band} isAuthed={true} /> )}/>
          <Route exact path='/services/occassion/suffi' render={(props) => ( <Subservice1 {...ArtContractSubParts.Suffi} isAuthed={true} /> )}/>
          <Route exact path='/services/occassion/gazal' render={(props) => ( <Subservice2 {...ArtContractSubParts.Gazal} isAuthed={true} /> )}/>
          <Route exact path='/services/occassion/instrumental' render={(props) => ( <Subservice2 {...ArtContractSubParts.Instrumental} isAuthed={true} /> )}/>
          <Route exact path='/services/occassion/devotional' render={(props) => ( <Subservice2 {...ArtContractSubParts.Devotional} isAuthed={true} /> )}/>
          <Route exact path='/services/occassion/western' render={(props) => ( <Subservice2 {...ArtContractSubParts.Western} isAuthed={true} /> )}/>
          <Route exact path='/services/occassion/classicaldance' render={(props) => ( <Subservice2 {...ArtContractSubParts.ClassicalDance} isAuthed={true} /> )}/>
          <Route exact path='/services/occassion/folk' render={(props) => ( <Subservice2 {...ArtContractSubParts.Folk} isAuthed={true} /> )}/>
          {/* <Route exact path='/services/occassion/bollywooddance' render={(props) => ( <Subservice2 {...ArtContractSubParts.BollywoodDance} isAuthed={true} /> )}/> */}
          <Route exact path='/error404' component={Error404} />
          <Redirect to='/Error404' />
        </Switch>
    <Footer />
      </div>
    </>
  );
}

export default App;
