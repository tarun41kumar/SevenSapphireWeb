export const home_slider = [
    {image:'https://unsplash.it/1920/1080?random=2'},
    {image:'https://unsplash.it/1920/1080?random=3'},
    {image:'https://unsplash.it/1920/1080?random=4'}
]