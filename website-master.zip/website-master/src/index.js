import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import {BrowserRouter} from 'react-router-dom'
import Amplify from 'aws-amplify';
// import config from '../src/aws-exports';
import config from '../node_modules/aws-amplify'
Amplify.configure(config);

ReactDOM.render(
  <>
  <BrowserRouter>
    <App />
  </BrowserRouter>
</>,
  document.getElementById('root')
);

