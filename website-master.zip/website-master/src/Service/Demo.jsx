
import { config } from '../config.json'
const aws = require('aws-sdk');

const Demo = () => {(async function() {
    try{

        aws.config.setPromisesDependency();
        aws.config.update({
            accessKeyId: config.aws.accessKey,
            secretAccessKey: config.aws.secretKey,
            region: 'us-east-2'
        })

        const s3 = new aws.S3();
        const response = await s3.listObjectsV2({
            Bucket: 'all-about-images',
            Prefix: 'Artist'
        }).promise();

        console.log(response);
    }catch(e) {
        console.log('our error',e);
    }

    debugger;
})();
}

export default Demo;