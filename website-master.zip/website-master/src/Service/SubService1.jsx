import React from 'react'

const SubArtContract1=(props)=>{
    console.log(props)
    return(
        <>

        <div className="w-100 my-5">
            <h1 className="text-center mx-auto mainHeading">{props.heading}</h1>
            <hr className="mainHr w-50 mx-auto my-3"/>
            <div className="row m-0">
                <div className="col-md-9 col-7">
                    <ul className="contractInfo w-100">
                        {props.content ? props.content.map((d, i) => (
                            <li className="subHeading text-center">{d}</li>                        
                        ))
                        : "loading"}
                    </ul>
                </div>
                <div className="col-md-3 col-5">
                    {/* <h4 className="text-center my-2 subHeading">{props.artist}</h4> */}
                    <img src={props.artistImage} alt=""/>
                    <ul className='w-100 artistInfo blurbg1'>
                        <li className="text-right mr-3">{props.artistName}</li>
                        <li className="text-right mr-3">{props.artistDegree}</li>
                    </ul>
                </div>
                <div className="col-12">
                </div>
                {props.work ? props.work.map((d, i) => (
                    <div className={props.classes}>
                        <img className="w-100" src={props.pathway+d} alt=""/>
                    </div>
                ))
                : "loading"}
                {props.video ? props.video.map((d, i) => (
                    <div className={props.classes}>
                        <iframe title={d} className="w-100 h-100 youvideo" src={"https://www.youtube.com/embed/"+d} frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                ))
                : ""}
            </div>
        </div>
        </>
    )
}

export default SubArtContract1;