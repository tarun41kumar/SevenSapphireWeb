import React from 'react'

const SubArtContract2=(props)=>{
    return(
        <>
        <div className="w-100 my-5">
            <h1 className="text-center mx-auto mainHeading">{props.heading}</h1>
            <hr className="mainHr w-50 mx-auto my-3"/>
            <div className="row m-0">
                <div className="col-md-6 order-md-2">
                    <ul className="dualcontractInfo py-md-5 w-100">
                        {props.content ? props.content.map((d, i) => (
                            <li className=" subHeading text-center ">{d}</li>                        
                        ))
                        : "loading"}
                    </ul>
                </div>
                <div className="col-md-3 col-6 order-md-1">
                    {/* <h5 className="text-center my-2 subHeading">{props.artist}</h5> */}
                    <img src={props.artistImage1} alt=""/>
                    <ul className='blurbg1 w-100 artistInfo'>
                        <li className="text-center mr-3">{props.artistName1}</li>
                        <li className="text-center mr-3">{props.artistDegree1}</li>
                    </ul>
                </div>
                <div className="col-md-3 col-6 order-md-3">
                    {/* <h5 className="text-center my-2 subHeading">{props.artist}</h5> */}
                    <img src={props.artistImage2} alt=""/>
                    <ul className='blurbg1 w-100 artistInfo'>
                        <li className="text-center mr-3">{props.artistName2}</li>
                        <li className="text-center mr-3">{props.artistDegree2}</li>
                    </ul>
                </div>
                <div className="col-12 order-md-4">
                </div>
                {props.work ? props.work.map((d, i) => (
                    <div className={props.classes}>
                        <img className="w-100" src={props.pathway+d} alt=""/>
                    </div>
                ))
                : "loading"}
                {props.video ? props.video.map((d, i) => (
                    <div className={props.classes}>
                        <iframe title={d} className="w-100 h-100 youvideo" src={"https://www.youtube.com/embed/"+d} frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                ))
                : ""}
            </div>
        </div>
        </>
    )
}

export default SubArtContract2;