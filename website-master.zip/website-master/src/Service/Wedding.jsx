import React from 'react'
import Slider from '../Components/WeddingSlider'
import {NavLink} from 'react-router-dom'
import {WeddingCard, StageDecoration } from '../Constant'

const Wedding=()=>{
    return(
    <>
    <div id="floatingpackage" className="position-fixed GeneralText">
            <NavLink to="/comingsoon"> 
                <span>Packages</span>
            </NavLink>
        </div>
        <Slider/>
        <h3 className="mainHeading text-center mt-4">Wedding Card</h3>
        <hr className="mainHr mx-auto"/>
        <h4 className="subHeading text-center">Choose your wedding Card</h4>
        <div className="row m-0">
        {WeddingCard ? WeddingCard.map((d, i) => (
            <div className="col-md-3 col-6 row m-0">
                <img src= {d.img} alt=""/>
                <h5 className="text-center col-12 subHeading">{d.name}</h5>
            </div>
            ))
            : "loading"}
        </div>

        <h3 className="mainHeading text-center mt-4">Stage Decoration</h3>
        <hr className="mainHr mx-auto"/>
        <h4 className="subHeading text-center">Design according to Theme</h4>
        <div id="ServiceGallery3" className="ServiceGallery">
            <div className="row w-100 m-0 p-0">
            {StageDecoration ? StageDecoration.map((d, i) => (
                <div className="col-md-4 col-sm-6 p-1">
                    <img src={d.img} alt=".."/>
                </div>
                ))
                : "loading"}
            </div>
        </div>
        <h3 className="mainHeading text-center mt-4">Ring Ceremony</h3>
        <hr className="mainHr mx-auto"/>
        <div id="ServiceGallery3" className="ServiceGallery">
            <div className="row w-100 m-0 p-0">
                <div className="row p-0 m-0 col-md-4">
                    <div className="col-md-12 col-sm-6 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/RingCeremony/ring1.jpg" alt=".."/>
                    </div>
                    <div className="col-md-12 col-sm-6 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/RingCeremony/ring3.jpg" alt=".."/>
                    </div>
                </div>
                <div className="col-md-4 p-1">
                    <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/RingCeremony/ring2.jpg" alt=".."/>
                </div>
                <div className="row m-0 p-0 col-md-4 ">
                    <div className="col-md-12 col-sm-6 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/RingCeremony/ring4.jpg" alt=".."/>
                    </div>
                    <div className="col-md-12 col-sm-6 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/RingCeremony/ring5.jpg" alt=".."/>
                    </div>
                </div>
          </div>
      </div>
        <h3 className="mainHeading text-center mt-4">photo shoot</h3>
        <hr className="mainHr mx-auto"/>
        <h5 className="subHeading text-center">Pre-wedding/wedding shoot</h5>
        <div id="ServiceGallery2" className="ServiceGallery">
            <div className="row m-0 p-0">
                <div className="row m-0 p-0 col-md-4">
                    <div className="col-12 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/PhotoShoot/photoShoot2.jpg" alt=".."/>
                    </div>
                    <div className="col-12 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/PhotoShoot/photoShoot1.jpg" alt=".."/>
                    </div>
                    <div className="col-12 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/PhotoShoot/photoShoot3.jpg" alt=".."/>
                    </div>
                </div>
                <div className="row m-0 p-0 col-md-4">
                    <div className="col-12 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/PhotoShoot/photoShoot5.jpg" alt=".."/>
                    </div>
                    <div className="col-12 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/PhotoShoot/photoShoot6.jpg" alt=".."/>
                    </div>
                </div>
                <div className="row m-0 p-0 col-md-4">
                    <div className="col-12 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/PhotoShoot/photoShoot4.jpg" alt=".."/>
                    </div>
                    <div className="col-12 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/PhotoShoot/photoShoot7.jpg" alt=".."/>
                    </div>
                    <div className="col-12 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/PhotoShoot/photoShoot8.jpg" alt=".."/>
                    </div>
                </div>
          </div>
      </div>
        <h3 className="mainHeading text-center mt-4">Spinster</h3>
        <hr className="mainHr mx-auto"/>
        <h4 className="subHeading text-center">bachelorette party at your style</h4>
        <div id="ServiceGallery3" className="ServiceGallery">
            <div className="row w-100 m-0 p-0">
                <div className="row p-0 m-0 col-md-4">
                    <div className="col-md-12 col-sm-6 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Spincter/spincter1.jpg" alt=".."/>
                    </div>
                    <div className="col-md-12 col-sm-6 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Spincter/spincter3.jpg" alt=".."/>
                    </div>
                </div>
                <div className="col-md-4 p-1">
                    <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Spincter/spincter2.jpg" alt=".."/>
                </div>
                <div className="row m-0 p-0 col-md-4 ">
                    <div className="col-md-12 col-sm-6 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Spincter/spincter4.jpg" alt=".."/>
                    </div>
                    <div className="col-md-12 col-sm-6 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Spincter/spincter5.jpg" alt=".."/>
                    </div>
                </div>
          </div>
      </div>
        <h3 className="mainHeading text-center mt-4">Mehndi Sangeet {'&'} Haldi</h3>
        <hr className="mainHr mx-auto"/>
        <div id="ServiceGallery2" className="ServiceGallery">
            <div className="row m-0 p-0">
                <div className="row m-0 p-0 col-md-4">
                    <div className="col-12 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Rituals/rituals2.jpg" alt=".."/>
                    </div>
                    <div className="col-12 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Rituals/rituals1.jpg" alt=".."/>
                    </div>
                    <div className="col-12 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Rituals/rituals5.jpg" alt=".."/>
                    </div>
                </div>
                <div className="row m-0 p-0 col-md-4">
                    <div className="col-12 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Rituals/rituals3.jpg" alt=".."/>
                    </div>
                    <div className="col-12 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Rituals/rituals8.jpg" alt=".."/>
                    </div>
                </div>
                <div className="row m-0 p-0 col-md-4">
                    <div className="col-12 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Rituals/rituals4.jpg" alt=".."/>
                    </div>
                    <div className="col-12 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Rituals/rituals7.jpg" alt=".."/>
                    </div>
                    <div className="col-12 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Rituals/rituals6.jpg" alt=".."/>
                    </div>
                </div>
          </div>
      </div>
        <h3 className="mainHeading text-center mt-4">Entertainment</h3>
        <hr className="mainHr mx-auto"/>
        <h4 className="subHeading text-center">Band, fire show, puppet show</h4>
        <div id="ServiceGallery3" className="ServiceGallery">
            <div className="row w-100 m-0 p-0">
                <div className="col-md-4 p-1">
                    <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Entertainment/entertainment1.jpg" alt=".."/>
                </div>
                <div className="col-md-4 col-sm-6 p-1">
                    <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Entertainment/entertainment2.jpg" alt=".."/>
                </div>
                <div className="col-md-4 col-sm-6 p-1">
                    <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Entertainment/entertainment3.jpg" alt=".."/>
                </div>
                <div className="col-md-8 p-1">
                <iframe title="weddingvideo1" className="w-100 h-100 youvideo"  src="https://www.youtube.com/embed/-k-8ikT4K8U" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                <div className="row m-0 col-md-4 m-0 p-0">
                    <div className="col-md-12 col-sm-6 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Entertainment/entertainment5.jpg" alt=".."/>
                    </div>
                    <div className="col-md-12 col-sm-6 p-1">
                        <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Entertainment/entertainment4.jpg" alt=".."/>
                    </div>
                </div>
            </div>
        </div>
        <div className= "row m-0 p-1">
        <iframe title="weddingvideo2" className="w-100 h-100 youvideo col-md-6 p-1" src="https://www.youtube.com/embed/SJlyi-Z52-E" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe title="weddingvideo3" className="w-100 h-100 youvideo col-md-6 p-1" src="https://www.youtube.com/embed/_ZSeNqEyMKc" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe title="weddingvideo4" className="w-100 h-100 youvideo col-md-6 p-1" src="https://www.youtube-nocookie.com/embed/jk5_hBpnhwo" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe title="weddingvideo5" className="w-100 h-100 youvideo col-md-6 p-1" src="https://www.youtube-nocookie.com/embed/udLjiQadAKk" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>

       <div className="row mx-0 my-3 p-0">
       <div className="col-md-6 order-md-2">
        <h3 className="mainHeading text-center mt-4">Our Partners</h3>
        <hr className="mainHr mx-auto"/>
        <ul className='w-100 text-center GeneralText text-capitalize'>
            <li>Arteye Stage Decoration Kolkata</li>
            <li>brothers productions gwalior m.p.</li>
            <li>F.D. Floral decoration Raipur C.G.</li>
            <li>Inside frame prodction raipur C.G.</li>
            <li>Ramesh tent and catering khairagarh C.G.</li>
        </ul>
        </div>
        <div className="col-md-3 p-1 col-6 order-md-1">
            <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/ankit.jpg" alt=".."/>
            <h4  className="text-center w-100 position-absolute blurbg">Ankit G.</h4>
        </div>
        <div className="col-md-3 p-1 col-6 order-md-3">
            <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/siddhart.jpg" alt=".."/>
            <h4  className="text-center w-100 position-absolute blurbg">Siddhart S.</h4>
        </div>
        </div>
    </>
    );
}

export default Wedding;