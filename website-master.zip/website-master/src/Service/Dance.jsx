import React from 'react'
import Swiper from '../Service/Swiper2/Swiper'
import Gallery from '../Service/Gallery3'

const Dance=()=>{
    return(
        <div className="container my-3">
            <h1 className="mainHeading text-center">Dance </h1>
            <hr className="mainHr mx-auto my-3"/>
            <div className="row">
                <Swiper />
				<Gallery />
            </div>

        </div>
    )
}

export default Dance;