import React from "react";

const Gallery2=()=> {
    return (
      <>
        <div id="ServiceGallery2" className="ServiceGallery">
            <div className="row m-0 p-0">
                <div className="row m-0 p-0 col-md-4">
                    <div className="col-12 p-1">
                        <img src="https://unsplash.it/1920/1080?random=2" alt=".."/>
                    </div>
                    <div className="col-12 p-1">
                        <img src="https://unsplash.it/1920/1080?random=1" alt=".."/>
                    </div>
                    <div className="col-12 p-1">
                        <img src="https://unsplash.it/1920/1080?random=2" alt=".."/>
                    </div>
                </div>
                <div className="row m-0 p-0 col-md-4">
                    <div className="col-12 p-1">
                        <img src="https://unsplash.it/1200/1080?random=2" alt=".."/>
                    </div>
                    <div className="col-12 p-1">
                        <img src="https://unsplash.it/1200/1080?random=4" alt=".."/>
                    </div>
                </div>
                <div className="row m-0 p-0 col-md-4">
                    <div className="col-12 p-1">
                        <img src="https://unsplash.it/1920/1080?random=5" alt=".."/>
                    </div>
                    <div className="col-12 p-1">
                        <img src="https://unsplash.it/1920/1080?random=7" alt=".."/>
                    </div>
                    <div className="col-12 p-1">
                        <img src="https://unsplash.it/1920/1080?random=8" alt=".."/>
                    </div>
                </div>
          </div>
      </div>
      </>
    );
  }

export default Gallery2;