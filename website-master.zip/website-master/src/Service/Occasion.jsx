import React from "react";
import {NavLink} from 'react-router-dom';

const Ocassion=()=> {
    return (
      <>
        <div id='Ocassion' className="w-100 py-3">
            <h1 className="mainHeading text-center">Occassion</h1>
            <hr className="mainHr mx-auto"/>
            <h4 className="subHeading text-center text-Capitalize">welcome to Wizard of music and dance</h4>
            <ul className='w-100 GeneralText'>
                <li className="text-center">FEST</li>
                <li className="text-center">ANNUAL FUNCTION</li>
                <li className="text-center">PARTY EVENTS</li>
                <li className="text-center">ANNIVERSARY BIRTHDAY</li>
                <li className="text-center">POLITICAL CAMPING</li>
                <li className="text-center">JAGRATA</li>
            </ul>
            
            <h4 className="mainHeading text-center">Choose your favorite wand</h4>
            <div className='row m-0 p-0'>
                <ul className='col-md-6 W-100 GeneralText font-weight-bold'>
                    <li className='text-center subHeading my-3'>MELODY WAND</li>
                    <li className='clickables text-light mt-1 p-1 wandheading'><NavLink to= "/services/occassion/devotional">DEVOTIONAL {">>"}</NavLink></li>
                    <li className='clickables text-light mt-1 p-1 wandheading'><NavLink to= "/services/occassion/gazal">Ghazal night {">>"}</NavLink></li>
                    <li className='clickables text-light mt-1 p-1 wandheading'><NavLink to= "/services/occassion/band">BOLLYWOOD BAND {">>"}</NavLink></li>
                    <li className='clickables text-light mt-1 p-1 wandheading'><NavLink to= "/services/occassion/suffi">Light Music {"&"} sufi night {">>"}</NavLink></li>
                    <li className='clickables text-light mt-1 p-1 wandheading'><NavLink to= "/services/occassion/instrumental">INSTRUMENTAL {"&"} ORCHESTRA {">>"}</NavLink></li>
                </ul>
                <ul className='col-md-6 W-100 GeneralText font-weight-bold'>
                    <li className='text-center subHeading my-3'>DANCE WAND</li>
                    <li className='clickables text-light mt-1 p-1 wandheading'><NavLink to= "/services/occassion/folk">FOLK DANCE {">>"}</NavLink></li>
                    <li className='clickables text-light mt-1 p-1 wandheading'><NavLink to= "/services/occassion/classicaldance">CLASSICAL DANCE {">>"}</NavLink></li>
                    <li className='clickables text-light mt-1 p-1 wandheading'><NavLink to= "/services/occassion/western">WESTERN {"&"} Bollywood DANCE {">>"}</NavLink></li>
                </ul>
            </div>
        </div>
      </>
    );
  }

export default Ocassion;