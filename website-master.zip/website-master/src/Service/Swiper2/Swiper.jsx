import React from 'react';
import Swiper from 'swiper';
import 'swiper/swiper-bundle.css';
import { Navigation } from 'swiper';
import { EminentArtist } from '../../Constant'


Swiper.use([Navigation]);
class Swiper2 extends React.Component {
  componentDidMount() {
    this.swiper = new Swiper('.swiper-container', {
      slidesPerView: Math.ceil(window.screen.width/200),
      spaceBetween: 10,
      slidesPerGroup:  Math.ceil(window.screen.width/200)-1,
      loop: true,
      loopFillGroupWithBlank: false,
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
    });
  }
  render() {
    return (
      <>
        <div id="swiper2" className="swiper-container ">
          <div className="swiper-wrapper">
            {EminentArtist ? EminentArtist.map((d, i) => (
              <div className="swiper-slide">
                <img  src= {"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Artist/"+d.src+".jpg"} alt="" />
              </div>
            ))
              : "loading"}
          </div>
          <div className="swiper-pagination"></div>
          <div className="swiper-button-next"></div>
          <div className="swiper-button-prev"></div>
        </div>
      </>
    )
  }
}
export default Swiper2