import React from "react";

const Gallery4=()=> {
    return (
      <>
        <div id="ServiceGallery3" className="ServiceGallery">
            <div className="row w-100 m-0 p-0">
                <div className="col-md-4 p-1">
                    <img src="https://unsplash.it/1920/1080?random=1" alt=".."/>
                </div>
                <div className="col-md-4 col-sm-6 p-1">
                    <img src="https://unsplash.it/1920/1080?random=2" alt=".."/>
                </div>
                <div className="col-md-4 col-sm-6 p-1">
                    <img src="https://unsplash.it/1920/1080?random=3" alt=".."/>
                </div>
                <div className="col-md-8 p-1">
                    <img src="https://unsplash.it/1920/1080?random=4" alt=".."/>
                </div>
                <div className="row m-0 col-md-4 m-0 p-0">
                    <div className="col-md-12 col-sm-6 p-1">
                        <img src="https://unsplash.it/1920/1080?random=5" alt=".."/>
                    </div>
                    <div className="col-md-12 col-sm-6 p-1">
                        <img src="https://unsplash.it/1920/1080?random=6" alt=".."/>
                    </div>
                </div>
            </div>
        </div>
      </>
    );
  }

export default Gallery4;