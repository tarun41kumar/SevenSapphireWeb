import React from 'react';
import Swiper from 'swiper';
import 'swiper/swiper-bundle.css';

import { Navigation } from 'swiper';
Swiper.use([Navigation]);
class Swiper_New extends React.Component {
    componentDidMount() {
    this.mySwiper = new Swiper('.swiper-container', {
        direction: "horizontal",
        loop: true,
        
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
        },
      
        scrollbar: {
          el: '.swiper-scrollbar',
        },
      })
    }
    render() {
        return (
            <>
                <div class="swiper-container">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide"><img src={"https://unsplash.it/1920/1080?random=2"} alt="img13"/></div>
                        <div class="swiper-slide"><img src={"https://unsplash.it/1920/1080?random=2"} alt="img13"/></div>
                        <div class="swiper-slide"><img src={"https://unsplash.it/1920/1080?random=3"} alt="img13"/></div>
                        <div class="swiper-slide"><img src={"https://unsplash.it/1920/1080?random=4"} alt="img13"/></div>
                        <div class="swiper-slide"><img src={"https://unsplash.it/1920/1080?random=5"} alt="img13"/></div>
                        <div class="swiper-slide"><img src={"https://unsplash.it/1920/1080?random=6"} alt="img13"/></div>
                        <div class="swiper-slide"><img src={"https://unsplash.it/1920/1080?random=7"} alt="img13"/></div>
                        <div class="swiper-slide"><img src={"https://unsplash.it/1920/1080?random=8"} alt="img13"/></div>
                        <div class="swiper-slide"><img src={"https://unsplash.it/1920/1080?random=9"} alt="img13"/></div>
                        <div class="swiper-slide"><img src={"https://unsplash.it/1920/1080?random=1"} alt="img13"/></div>
                    </div>                    


                    <div class="swiper-button-next"></div>                    
                    <div class="swiper-button-prev"></div>    
                                    
                    <div class="swiper-scrollbar"></div>               
                     </div>
            </>
        )
    }
}
export default Swiper_New