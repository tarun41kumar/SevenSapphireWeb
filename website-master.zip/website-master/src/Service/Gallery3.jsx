import React from "react";

const Gallery3=()=> {
    return (
      <>
        <div id="ServiceGallery3" className="ServiceGallery">
            <div className="row w-100 m-0 p-0">
                <div className="row p-0 m-0 col-md-4">
                    <div className="col-md-12 col-sm-6 p-1">
                        <img src="https://unsplash.it/1920/1080?random=4" alt=".."/>
                    </div>
                    <div className="col-md-12 col-sm-6 p-1">
                        <img src="https://unsplash.it/1920/1080?random=4" alt=".."/>
                    </div>
                </div>
                <div className="col-md-4 p-1">
                    <img src="https://unsplash.it/960/1080?random=4" alt=".."/>
                </div>
                <div className="row m-0 p-0 col-md-4 ">
                    <div className="col-md-12 col-sm-6 p-1">
                        <img src="https://unsplash.it/1920/1080?random=4" alt=".."/>
                    </div>
                    <div className="col-md-12 col-sm-6 p-1">
                        <img src="https://unsplash.it/1920/1080?random=4" alt=".."/>
                    </div>
                </div>
          </div>
      </div>
      </>
    );
  }

export default Gallery3;