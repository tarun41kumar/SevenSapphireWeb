import React from 'react'
import {ArtContractData} from '../Constant'
import { NavLink} from 'react-router-dom'

const ArtContract=()=>{
    return(
    <div className="w-100 my-3">
        <h1 className="mainHeading text-center">Art Contract </h1>
        <hr className="mainHr mx-auto my-3"/>
        <div className="row m-0 p-2">
        {ArtContractData ? ArtContractData.map((d, i) => (
            <div className="col-md-4 col-sm-6 p-1">
                <NavLink to= {d.path} > <img className="w-100 h-100" src={d.img} alt='..'/>
                <h4  className="text-center w-100 position-absolute subHeading blurbg">{d.name}</h4>
                </NavLink>
            </div>
            ))
            : "loading"}
        </div>
    </div>
    )
}

export default ArtContract;