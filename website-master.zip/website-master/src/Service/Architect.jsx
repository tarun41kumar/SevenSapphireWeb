import React from 'react'
import { NavLink} from 'react-router-dom'

const Architect=()=>{
    return(
    <div className="w-100 my-3">
        <h1 className="mainHeading text-center">Architect {'&'} Interior Design </h1>
        <hr className="mainHr mx-auto my-3"/>
        <div className="row m-0 p-2">
            <div className="col-md-6 p-1">
                <NavLink to= "/services/design/architect" ><img className="w-100 h-100 p-md-5 p-2" src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Architect/architect.jpg" alt='architect'/>
                <h3  className="text-center w-100 position-absolute subHeading blurbg">Architect</h3>
                </NavLink>
            </div>
            <div className="col-md-6 p-1">
                <NavLink to= "/services/design/interior" ><img className="w-100 h-100 p-md-5 p-2" src="https://all-about-images.s3.us-east-2.amazonaws.com/Service/Architect/interior.jpg" alt='interior'/>
                <h3  className="text-center w-100 position-absolute subHeading blurbg">Interior Design</h3>
                </NavLink>
            </div>
        </div>
    </div>
    )
}

export default Architect;