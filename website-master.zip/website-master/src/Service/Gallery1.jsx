import React from "react";

const Gallery1=()=> {
    return (
      <>
      <div id="ServiceGallery1" className="ServiceGallery">
          <div className="row w-100 m-0 p-0">
              <div className="col-md-5 p-1">
                  <img src="https://unsplash.it/1920/1080?random=1" alt=".."/>
              </div>
              <div className="col-md-5 p-1">
                  <img src="https://unsplash.it/1920/1080?random=2" alt=".."/>
              </div>
              <div className="offset-md-2 col-md-5 p-1">
                  <img src="https://unsplash.it/1920/1080?random=3" alt=".."/>
              </div>
              <div className="col-md-5 p-1">
                  <img src="https://unsplash.it/1920/1080?random=4" alt=".."/>
              </div>
          </div>
      </div>
      </>
    );
  }

export default Gallery1;