import React from "react";
import {homeFeatures} from '../Constant'

const Features= ()=> {
    return (
      <div id="features" className="text-center my-5">
        <div className="w-100">
          <div className="section-title text-center">
            <h1 className='mainHeading'>Features</h1>
            <hr className='mainHr mx-auto'/>
          </div>
          <div className="section-content row m-0">
            {homeFeatures ? homeFeatures.map((d,i) => (
                  <div  key={`${d.title}-${i}`} className="col-6 col-md-3">
                    <i className={d.icon}></i>
                    <h4>{d.title}</h4>
                    <p>{d.text}</p>
                  </div>
                ))
              : "Loading..."}
          </div>
        </div>
      </div>
    );
  }

export default Features;