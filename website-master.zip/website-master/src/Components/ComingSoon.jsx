import React from 'react'

const ComingSoon=()=>{
    return(
    <>
    <div className="comingsoon">
        <img className='w-100' src="https://all-about-images.s3.us-east-2.amazonaws.com/Images/comingsoon.gif" alt=""/>
    </div>
    </>
    )
}
export default ComingSoon