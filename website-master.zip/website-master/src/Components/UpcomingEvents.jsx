import React, {Component} from 'react';
// import {NavLink} from 'react-router-dom'

class UpcomingEvents extends Component {

    state = {
        isopen: true
    }
    handleClick = () => {
        this.setState({
            isopen: false
        })
    }
    render(){
    return(
        <>
        <div id="UpcomingEvents" className={`vh-100 vw-100 m-0 p-0 position-fixed ${this.state.isopen?'':'d-none'}`} 
            onClick={this.handleClick}
            style={{top:'0%',
                    zIndex:65}}>
            <span>+</span>
            <div className='w-75 mx-auto my-2 text-center'
                style={{zIndex:70}}>
                <h2 className='subHeading'>Upcoming Events</h2>
                <h4 className='subHeading'>Registration Open</h4>
                <p>for Umaria (M.P.)</p>
                <div className='imgelink' >
                    <a href='https://forms.gle/Lh19fMuhrxbpVELn9' 
                        target="_blank" 
                        rel="noreferrer">
                    <img className='w-100 m-0 p-0' 
                        src='https://all-about-images.s3.us-east-2.amazonaws.com/Images/upcomingEvents.jpg' 
                        alt=''/>                
                    </a>
                </div>
            </div>
        </div>
        </>
    )
    }
}

export default UpcomingEvents;