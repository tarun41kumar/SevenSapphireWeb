import React from "react";
import { NavLink } from "react-router-dom";
import { homeGallery } from '../Constant'


const Gallery = () => {
  return (
    <>
      <div id="gallery" className="text-center">
        <div className="w-100 my-5">
          <div className="section-title">
            <h1 className='mainHeading'>Gallery</h1>
            <hr className='mainHr mx-auto' />
          </div>
          <div className="row m-0">
            {homeGallery ? homeGallery.map((d, i) => (
              <div className="col-md-3 col-sm-6 p-0">
                <NavLink to={d.goto}><div className="homeGallery">
                  <img className="img-homeGallery" src={d.image_url} alt="" />
                  <div className="overlay">
                    <h2>{d.name}</h2>
                    <NavLink className="info" to={d.goto}>Show More</NavLink>
                  </div>
                </div></NavLink>
              </div>
            ))
              : "...loading"}
              {/* {HomeVideo ? HomeVideo.map((d, i) => (
                    <div className="col-md-6 p-3">
                        <iframe title={d} className="w-100 h-100 youvideo" src={"https://www.youtube.com/embed/"+d} frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                ))
                : ""} */}
          </div>
        </div>
      </div>
    </>
  );
}

export default Gallery;