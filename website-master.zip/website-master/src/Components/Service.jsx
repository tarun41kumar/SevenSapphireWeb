import React from 'react';
import { NavLink } from 'react-router-dom';
import { homeServices } from '../Constant';

const HomeService = () => {
    return (
        <div id="services" className="text-center">
            <div className="w-100 my-5">
                <div className="section-title">
                    <h1 className='mainHeading'>Our Services</h1>
                    <hr className='mainHr mx-auto' />
                </div>
                <div className="row m-0">
                    {homeServices ? homeServices.map((d, i) => (
                       <div class="col-md-3 col-sm-6 service-sections p-2">
                             <NavLink to={d.goto}><div class="homeservice service-image">
                                <img class="img-homeservice" src={d.image} alt="" />
                                <div class="overlay">
                                    <h2>{d.name}</h2>
                                    <p>
                                        Know More
                                    </p>
                                </div>
                            </div> </NavLink>
                        </div>
                    ))
                        : "loading"}
                </div>
            </div>
        </div>
    )
}

export default HomeService;