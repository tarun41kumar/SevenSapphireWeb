import React from 'react'

const PrimeServices = ()=> {
    return(
      <>
      <div id="PrimeServices">
      <div className="container py-3">
        <div className="row">
          <div className="PrimeServices-img col-12 col-md-6 py-0 d-none d-md-block"> 
            <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Images/fservice.jpg" alt=""/> 
          </div>
          <div className="PrimeServices-text m-0 col-md-6">
            <h1 className="mainHeading text-center pt-lg-5">Featured Services</h1>
            <hr className='mainHr w-50 my-lg-5 mx-auto'/>
            <ul className="row m-0">
              <li className='text-left GeneralText mb-2'>
                <a href="https://wa.me/917879549841/?text=Hey%2C%20Can%20You%20make%20my%20Portrait" target="_blank" rel="noopener noreferrer">
                  Order
                </a>
                {"<--"} Get Your Portrait
              </li>
              <li className='text-left GeneralText mb-2'>
                <a href="https://wa.me/917879549841/?text=Hey%2C%20I%20want%20my%20Home%20Interior%20to%20shine%20like%20me.%20Can%20you%20help%3F" target="_blank" rel="noopener noreferrer">
                  Order
                </a>
                {"<--"} Design Home Interior
              </li>
              <li className='text-left GeneralText mb-2'>
                <a href="https://wa.me/917879549841/?text=Hey%2C%20Can%20You%20make%20my%20Sculpture" target="_blank" rel="noopener noreferrer">
                  Order
                </a>
                {"<--"} Get Your Sculpture
              </li>
              <li className='text-left GeneralText mb-2'>
                <a href="https://wa.me/917879549841/?text=Hey%2C%20I%20Have%20a%20query%20regarding%20Artists." target="_blank" rel="noopener noreferrer">
                  Order
                </a>
                {"<--"} Hire Bollywood, Classical {"&"} Western Artists. Orchestra, Singer, Band, Dancer {"&"} Choreographer.</li>
            </ul>
          </div>
        </div>
      </div>
      </div>
      </>
    )
}

export default PrimeServices;