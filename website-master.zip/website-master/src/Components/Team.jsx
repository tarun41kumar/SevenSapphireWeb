import React from "react";
import {homeTeambtd, homeTeammdt} from '../Constant'

const Team =()=>{
    return (
    <div id="team" className="text-center">
      <div className="container my-3">
          <h1 className="mainHeading">Meet the Team</h1>
          <hr className="mx-auto mainHr w-50"/>
        <div className="row m-0 Teampeople">
          <div key="1" className="row m-0 col-md-6 offset">
            <div className="col-12">
              <h3 className="subHeading">Founder</h3>
            </div>
              <div className="thumbnail col-sm-6 offset-sm-3">
                <img src={"https://all-about-images.s3.us-east-2.amazonaws.com/Team/alakh.jpg"} alt="..." className="team-img" />
                <div className="caption">
                  <h4 className="subHeading">Alakh Khare</h4>
                  <p className="GeneralText">BFA/MFA Painting</p>
                </div>
              </div>
          </div>
          <div className="row m-0 col-md-6">
            <div className="col-12">
              <h3 className="subHeading">Tech Team</h3>
            </div>
            {homeTeambtd? homeTeambtd.map((d, i) => (
              <div  key={`${d.name}-${i}`} className="col-sm-6">
                <div className="thumbnail position-relative">
                  <img src={d.img} alt="..." className="team-img" />
                  <div className="overlayteam position-absolute">
                    <div className="icon-links d-flex justify-content-around">
                      <a href={d.linkedin} target="_blank" rel="noreferrer">
                        <span className="fa fa-linkedin"></span>
                      </a>
                      <a href={d.whatsapp} target="_blank" rel="noreferrer">
                        <span className="fa fa-whatsapp"></span>
                      </a>
                      <a href={d.email} target="_blank" rel="noreferrer">
                        <span className="fa fa-envelope"></span>
                      </a>
                      <a href={d.twitter} target="_blank" rel="noreferrer">
                        <span className="fa fa-twitter"></span>
                      </a>
                    </div>
                  </div>
                  </div>
                  <div className="caption">
                    <h4 className="subHeading">{d.name}</h4>
                    <p className="GeneralText">{d.edu}</p>
                  </div>
                </div>
            )): "loading"}
          </div>
          <div className="row m-0 col-12">
            <div className="col-12">
              <h3 className="subHeading">Managing {"&"} Directing Team</h3>
            </div>
            {homeTeammdt? homeTeammdt.map((d, i) => (
              <div  key={`${d.name}-${i}`} className="col-md-3 col-sm-6">
                <div className="thumbnail">
                  <img src={d.img} alt="..." className="team-img" />
                  <div className="caption">
                    <h4 className="subHeading">{d.name}</h4>
                    <p className="GeneralText">{d.edu}</p>
                  </div>
                </div>
              </div>
            )): "loading"}
          </div>
        </div>
      </div>
    </div>
    );
  }

export default Team;