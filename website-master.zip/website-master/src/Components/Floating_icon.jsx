import React from 'react'

const FloatingLogo=()=>{
    return(
        <>
        {/* <div id="floatingpackage" className='position-fixed'>
            <NavLink to="/comingsoon"> 
                <span>Packages</span>
            </NavLink>
        </div> */}
        <ul id='floatinglogo' className="social position-fixed">
            <li>
                <a href="https://wa.me/917879549841/?text=Hey%2C%20I%20have%20some%20query%20regarding%20SevenSapphires%20Packages." target="_blank" rel="noopener noreferrer">
                    <i className="fa fa-whatsapp"></i>
                </a>
            </li>
            <li>
                <a href="tel:+917879549841" target="_blank" rel="noopener noreferrer"> 
                    <i className="fa fa-phone"></i> 
                </a>
            </li>
            <li>
                <a href="mailto:infosevensapphires@gmail.com" target="_blank" rel="noopener noreferrer">
                    <i className="fa fa-envelope"></i> 
                </a>
            </li>
        </ul>
        </>
    )
}

export default FloatingLogo;