import React from 'react';
// import { NavLink } from 'react-router-dom';

const HomeImageSlider = () => {
  return (
    <>   
    
<div id="demo" class="carousel slide" data-ride="carousel">

  {/* <!-- Indicators --> */}
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  
  {/* <!-- The slideshow --> */}
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img className="w-100" src="https://all-about-images.s3.us-east-2.amazonaws.com/Home_Slider/homeslider3.jpg" alt="Los Angeles"/>
    </div>
    <div class="carousel-item">
      <img className="w-100" src="https://all-about-images.s3.us-east-2.amazonaws.com/Home_Slider/homeslider2.jpg" alt="Los Angeles"/>
    </div>
    <div class="carousel-item">
      <img className="w-100" src="https://all-about-images.s3.us-east-2.amazonaws.com/Home_Slider/homeslider1.jpg" alt="Los Angeles"/>
    </div>
  </div>
  
  {/* <!-- Left and right controls --> */}
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
    </>
  );
};

export default HomeImageSlider;
