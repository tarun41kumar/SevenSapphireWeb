import React, { useEffect, useState } from "react"
// import "./Demo.css"
import { Demo } from '../Constant'

function ImageAlbum() {
    const [tag, setTag] = useState('all');
    const [ filteredImages, setFilteredImages] = useState([]);

    useEffect( () => {
        tag === 'all' ? setFilteredImages(Demo): setFilteredImages(Demo.filter( image => image.tag === tag))
    }, [tag])
    return (
        <div className="container gallery-container">
            <h1>Bootstrap 3 Gallery</h1>
            <p className="page-description text-center">Grid Layout With Zoom Effect</p>
            <div className="tz-gallery">
            <TagButton  name= "all" handlesetTag={setTag}/>
            <TagButton  name= "marriage" handlesetTag={setTag} />
            <TagButton  name= "occasion" handlesetTag={setTag}/>
            <TagButton  name= "event" handlesetTag={setTag} />
            <TagButton  name= "art" handlesetTag={setTag}/>
            <TagButton  name= "birthday" handlesetTag={setTag}/>
            <TagButton  name= "music" handlesetTag={setTag}/>
                <div className="row">
                    {filteredImages.map(image =>
                    
                        <div key={image.id} className="col-sm-6 col-md-4">
                            <a className="lightbox" href={image.url}>
                            <img src={image.url} alt="Park" />
                            </a>
                        </div>
                    )}

                </div>
            </div>
        </div>
    )
}


const TagButton = ( {name, handlesetTag }) => {
    return <button onClick={ () => handlesetTag(name)}>{ name.toUpperCase() }</button>
}
export default ImageAlbum

