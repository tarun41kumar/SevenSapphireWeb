import React from 'react'
import {homeAbout} from '../Constant'

const About=()=> {
    return (
        <div id="about">
        <div className="container py-3">
          <div className="row">
            <div className="about-img col-12 col-md-6 py-0 d-none d-md-block"> 
              <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Images/about.jpg" alt=""/> 
            </div>
            <div className="about-text m-0 col-md-6">
              <h1 className="mainHeading text-center pt-lg-5">About Us</h1>
              <hr className='mainHr w-50 my-lg-5 mx-auto'/>
              <h5 className='GeneralText text-justify'>{homeAbout ? homeAbout.heading : 'loading...'}</h5>
              <p className='GeneralText text-justify'>{homeAbout ? homeAbout.paragraph : 'loading...'}</p>
            </div>
          </div>
        </div>
        </div>
      
    )
  }

export default About