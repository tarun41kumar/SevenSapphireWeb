import React from 'react'
import {photos} from '../Constant'


const MainGallery=()=>{
    const p1=photos.slice(0,photos.length/3)
    const p2=photos.slice(photos.length/3,2*photos.length/3)
    const p3=photos.slice(2*photos.length/3,photos.length)
    const p4=photos.slice(0,photos.length/2)
    const p5=photos.slice(photos.length/2,photos.length)
    const pic_big =[p1,p2,p3]
    const pic_small=[p4,p5]
    return(
    <>
    <div className="w-100 row m-0">
        {pic_big?pic_big.map((p,i)=>(
            <div className="col-lg-4 d-none d-lg-block m-0 p-0">
                {p?p.map((d,i)=>(
                    <div className="col-12 p-2 m-0">
                        <img className="w-100" src={"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Photography/photography"+d+".jpg"} alt=".."/>
                    </div>
                )):"Loading"}        
            </div>
        )):"Loading"}
    </div>
    <div className="w-100 row m-0">
        {pic_small?pic_small.map((p,i)=>(
            <div className="col-sm-6 d-lg-none m-0 p-0">
                {p?p.map((d,i)=>(
                    <div className="col-12 p-2 m-0">
                        <img className="w-100" src={"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Photography/photography"+d+".jpg"} alt=".."/>
                    </div>
                )):"Loading"}        
            </div>
        )):"Loading"}
    </div>
    </>
    )

}
export default MainGallery;