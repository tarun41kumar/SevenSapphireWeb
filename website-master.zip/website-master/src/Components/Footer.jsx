import React from 'react'

const Footer= ()=>{
    return(
        <>    
        <div id="mainFooter" className="w-100">
            <div className="row"></div>             
            <ul className="social text-center pt-5">
                <li>
                    <a href="https://wa.me/917879549841/?text=Hey%2C%20I%20have%20some%20query%20regarding%20SevenSapphires%20Packages." 
                        target="_blank" 
                        rel="noopener noreferrer">
                        <i className="fa fa-whatsapp"></i>
                    </a>
                </li>
                <li>
                    <a href="tel:+917879549841" 
                        target="_blank" 
                        rel="noopener noreferrer">
                    <i className="fa fa-phone"></i>
                    </a>
                </li>
                <li>
                    <a href="mailto:infosevensapphires@gmail.com" target="_blank" rel="noopener noreferrer">
                        <i className="fa fa-envelope"></i>
                    </a>
                </li> 
                <li>
                    <a href="https://www.facebook.com/" target="_blank" rel="noopener noreferrer">
                        <i className="fa fa-facebook"></i>
                    </a>
                </li>
                <li>
                    <a href="https://twitter.com/7_sapphires" target="_blank" rel="noopener noreferrer">
                        <i className="fa fa-twitter"></i>
                    </a>
                </li>
                <li>
                    <a href="https://www.youtube.com/channel/UC_Z-wEjAaZLMjKH2XZWozNQ"  target="_blank" rel="noopener noreferrer">
                        <i className="fa fa-youtube"></i>
                    </a>
                </li>     
            </ul>
            <hr className="bg-light w-50 mx-auto"/>
            <div className="footer container text-light text-center py-2">
                <p>&copy; 2020, Company Inc. All Rights Reserved. Design By: Jansan {"&"} Tarun</p>
            </div>
            </div>


        </>
    );
}
export default Footer;