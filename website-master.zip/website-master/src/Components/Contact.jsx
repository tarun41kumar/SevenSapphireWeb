import React, { useState } from 'react';
import axios from 'axios';
import { Form, Button } from 'react-bootstrap';

const Contact = () => {
  const [state, setState] = useState({
    name: '',
    email: '',
    mobile:'',
    subject: '',
    message: ''
  });

  const [result, setResult] = useState(null);

  const sendEmail = event => {
    event.preventDefault();
    axios
      .post('/send', { ...state })
      .then(response => {
        setResult(response.data);
        setState({
          name: '',
          email: '',
          mobile:'',
          subject: '',
          message: ''
        });
      })
      .catch(() => {
        setResult({
          success: false,
          message: 'Something went wrong. Try contacting us through whatsapp or call'
        });
      });
  };

  const onInputChange = event => {
    const { name, value } = event.target;

    setState({
      ...state,
      [name]: value
    });
  };

  return (
  <div id="homeContact" className="text-center">
    <div className="container my-5">
      <div className="section-title">
        <h1 className='mainHeading'>Get in Touch</h1>
        <hr className='mainHr mx-auto'/>
        <p className="GeneralText">Please fill out the form below to send us an email and we will get back to you as soon as possible.</p>
      </div>
      <div className="row m-0">
        <div className="homeContactimage col-md-6">
          <img src="https://all-about-images.s3.us-east-2.amazonaws.com/Images/image_contact.png" alt='contact'/>
        </div>
        <div className="col-md-6 pt-2">
          {result && (
            <p className={`${result.success ? 'success' : 'error'}`}>
              {result.message}
            </p>
          )}
          <form onSubmit={sendEmail}>
            <Form.Group className="form-group" controlId="name">
              <Form.Control
                className="form-control"
                type="text"
                name="name"
                value={state.name}
                placeholder="Enter your full name"
                onChange={onInputChange}
              />
            </Form.Group>
            <Form.Group className="form-group" controlId="email">
              <Form.Control
                className="form-control"
                type="text"
                name="email"
                value={state.email}
                placeholder="Enter your email"
                onChange={onInputChange}
              />
            </Form.Group>
            <Form.Group className="form-group" controlId="phone">
              <Form.Control
                className="form-control"
                type="number"
                name="phone"
                value={state.phone}
                placeholder="Enter your Mobile Number"
                onChange={onInputChange}
              />
            </Form.Group>
            <Form.Group className="form-group" controlId="subject">
              <Form.Control
                className="form-control"
                type="text"
                name="subject"
                value={state.subject}
                placeholder="Enter subject"
                onChange={onInputChange}
              />
            </Form.Group>
            <Form.Group className="form-group" controlId="subject">
              <Form.Control
                className="form-control"
                as="textarea"
                name="message"
                value={state.message}
                rows="3"
                placeholder="Enter your message"
                onChange={onInputChange}
              />
            </Form.Group>
            <Button variant="primary" type="submit">
              Submit
            </Button>
          </form>
        </div>
      </div>
    </div>
  </div>
  );
};

export default Contact;