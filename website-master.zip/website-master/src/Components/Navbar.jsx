import React, {Component} from 'react';
import {NavLink} from 'react-router-dom'

class Navbar extends Component {

    state = {
        isopen: false
    }

    handleClick = () => {
        this.setState({
            isopen: !this.state.isopen,
        })
    }

    closeNavbar = () => {
        this.setState({
            isopen: false
        })
    }
    render(){
    return(
        <>
        <div id="main_navbar">
            <nav>
                <input type="checkbox" id="check" checked={this.state.isopen}/>
                <label for="check" className="checkbtn" onClick={this.handleClick}>
                    <i className="fas fa-bars"></i>
                </label>
                <label className="logo GeneralText" onClick={this.closeNavbar}><NavLink  exact to="/"><span>7Sapphires</span></NavLink></label>
                <ul onClick={this.closeNavbar} className="GeneralText">
                    <li><NavLink  exact to="/">Home</NavLink></li>
                    <li><NavLink  to="/about">About</NavLink></li>
                    {/* <li><NavLink  to="/photography">Photography</NavLink></li> */}
                    <li><NavLink  to="/services">Services</NavLink></li>
                    <li><NavLink  to="/contact">Contact</NavLink></li>
                    {/* <li><NavLink  to="/comingsoon">Gifts</NavLink></li> */}
                </ul>
                <div className={`vh-100 w-100 position-fixed ${this.state.isopen?'':'d-none'}`}
                    onClick={this.closeNavbar} 
                    style={{top:'10%',
                    zIndex:55}}>
                </div>
            </nav>
        </div>
        </>
    )
    }
}

export default Navbar;