export const SocialIcon={
    "address": "4321 California St, San Francisco, CA 12345 ",
    "phone": "+1 123 456 1234",
    "email": "info@company.com",
    "facebook": "fb.com",
    "twitter": "twitter.com",
    "youtube": "youtube.com"
}

export const slider_images = [
    {image:'https://all-about-images.s3.us-east-2.amazonaws.com/Home_Slider/homeslider1.jpg'},
    {image:'https://all-about-images.s3.us-east-2.amazonaws.com/Home_Slider/homeslider2.jpg'},
    {image:'https://all-about-images.s3.us-east-2.amazonaws.com/Home_Slider/homeslider3.jpg'}
]

export const Pages=[
    {urlHref:'/', pageName:'Home'},
    {urlHref:"/about", pageName:'About'},
    {urlHref:"/services", pageName:'Services'},
    {urlHref:"/contact", pageName:'Contact'},
    {urlHref:"/gallery", pageName:'Gallery'}
  ]

export const EminentArtist = [
        {src: "arvind"},
        {src: "dibakar"},
        {src: "isha"},
        {src: "kanchan"},
        {src: "lokesh"},
        {src: "nagendra"},
        {src: "narindra"},
        {src: "nutun"},
        {src: "arnab"},
        {src: "prabhat"},
        {src: "raja"},
        {src: "rajveer"},
        {src: "sugam"},
        {src: "sukhsagar"},
        {src: "swapneel"},
        {src: "sweta"},
        {src: "vikas"}
        // ,{src: "likesh"}
      ];
      
export const photos = ["1","2","3","4","5","6","8","9","10",
"11","12","13","14","15","16","17","18","19","20","21","22","23","24",
"25"];
export const homeAbout= {
            "heading": " 'A human without art is just like a bird without wings.' ",
            "paragraph": "A group of trained artists making a way towards spreading art and its culture into each and every corner of livelihood; aiming towards a service through art so, that everyone has a taste of it which means creating opportunities for more No. of artists."
        }

export const homeServices= [
            {
                "name": "Wedding",
                "image": "https://all-about-images.s3.us-east-2.amazonaws.com/Service_Background/wedding.jpg",
                "goto": "/services/wedding"
            },
            {
                "name": "Art Contract",
                "image": "https://all-about-images.s3.us-east-2.amazonaws.com/Service_Background/artcontract.jpg",
                "goto": "/services/artcontract"
            },
            {
                "name": "Occassion",
                "image": "https://all-about-images.s3.us-east-2.amazonaws.com/Service_Background/occassion.jpg",
                "goto": "/services/occassion"
            },
            {
                "name": "Architect & Interior Design",
                "image": "https://all-about-images.s3.us-east-2.amazonaws.com/Service_Background/architect.jpg",
                "goto": "/services/design"
            }
            ]

export const homeTeambtd= [
    {
        "img": "https://all-about-images.s3.us-east-2.amazonaws.com/Team/tarun.jpg",
        "name": "Tarun Kumar",
        "edu": "B.Tech IKGPTU",
        "job": "Developer",
        "linkedin": "http://www.linkedin.com/in/tarun-kumar-101",
        "whatsapp": "https://wa.me/918950085848/?text=Hey%2C%20I%20have%20some%20query%20regarding%20SevenSapphires%20Packages.",
        "email":"mailto:tarun40kumar@gmail.com",
        "twitter":"https://twitter.com/grover_tarun_"
      },
      {
        "img": "https://all-about-images.s3.us-east-2.amazonaws.com/Team/jansan.jpg",
        "name": "Jansan S.",
        "edu": "B.Tech IITB",
        "job": "Developer",
        "linkedin": "https://www.linkedin.com/in/jansan-shivhare-8b40a0118/",
        "whatsapp": "https://wa.me/919399582277/?text=Hey%2C%20I%20have%20some%20query%20regarding%20SevenSapphires%20Packages.",
        "email":"mailto:jansanshivhare@gmail.com",
        "twitter":"https://twitter.com/jansantw"
        }
        
      ]

export const homeTeammdt= [

    {
        "img": "https://all-about-images.s3.us-east-2.amazonaws.com/Team/prince.jpg",
        "name": "Prince Patel",
        "edu": "B.Arch NIT Nagpur",
        "job": "Architect",
      },
            
    {
        "img": "https://all-about-images.s3.us-east-2.amazonaws.com/Team/sumanshree.jpg",
        "name": "Suman Shree",
        "edu": "BFA/MFA Painting",
        "job": "Product Manager",
    },
    {
        "img": "https://all-about-images.s3.us-east-2.amazonaws.com/Team/neelesh.jpg",
        "name": "Neelesh Yadav",
        // "edu": "BFA/MFA Painting",
        "job": "The Artist",
    },
    {
        "img": "https://all-about-images.s3.us-east-2.amazonaws.com/Team/vikash.jpg",
        "name": "Dr. Vikas Agarwal",
        // "edu": "Doctor",
        "job": "Product Manager",
        }
            
          ] 



export const homeFeatures=[
            {
                "icon": "fa fa-comments-o",
                "title": "Lorem ipsum",
                "text": "Lorem ipsum dolor sit amet placerat facilisis felis mi in tempus eleifend pellentesque natoque etiam."
            },
            {
                "icon": "fa fa-bullhorn",
                "title": "Lorem ipsum",
                "text": "Lorem ipsum dolor sit amet placerat facilisis felis mi in tempus eleifend pellentesque natoque etiam."
            },
            {
                "icon": "fa fa-group",
                "title": "Lorem ipsum",
                "text": "Lorem ipsum dolor sit amet placerat facilisis felis mi in tempus eleifend pellentesque natoque etiam."
            },
            {
                "icon": "fa fa-magic",
                "title": "Lorem ipsum",
                "text": "Lorem ipsum dolor sit amet placerat facilisis felis mi in tempus eleifend pellentesque natoque etiam."
            }
        ]

export const homeGallery=[
    {"goto": "/services/artcontract/portrait", "name":"Digital Painting", "image_url":"https://all-about-images.s3.us-east-2.amazonaws.com/Home_Gallery/r1c1.jpg"},
    {"goto": "/services/artcontract/portrait", "name":"Portrait", "image_url":"https://all-about-images.s3.us-east-2.amazonaws.com/Home_Gallery/r1c2.jpg"},
    {"goto": "/services/artcontract/sculpture", "name":"Sculpture", "image_url":"https://all-about-images.s3.us-east-2.amazonaws.com/Home_Gallery/r1c3.jpg"} ,
    // {"goto": "/comingsoon", "name":"Photography", "image_url":"https://all-about-images.s3.us-east-2.amazonaws.com/Home_Gallery/r2c1.jpg"},
    {"goto": "/services/occassion/band", "name":"Bollywood Band", "image_url":"https://all-about-images.s3.us-east-2.amazonaws.com/Home_Gallery/r2c2.jpg"} ,
    {"goto": "/services/occassion/classicaldance", "name":"Kathak", "image_url":"https://all-about-images.s3.us-east-2.amazonaws.com/Home_Gallery/r2c3.jpg"},
    {"goto": "/services/artcontract/wallpainting", "name":"Wall Painting", "image_url":"https://all-about-images.s3.us-east-2.amazonaws.com/Home_Gallery/r3c1.jpg"},
    {"goto": "/services/artcontract/tattoo", "name":"Tattoo", "image_url":"https://all-about-images.s3.us-east-2.amazonaws.com/Home_Gallery/r3c2.jpg"},
    {"goto": "/services/artcontract/rangoli", "name":"Rangoli", "image_url":"https://all-about-images.s3.us-east-2.amazonaws.com/Home_Gallery/r3c3.jpg"},
    // {"goto": "/comingsoon", "name":"Craft", "image_url":"https://all-about-images.s3.us-east-2.amazonaws.com/Home_Gallery/r4c1.jpg"},
    // {"goto": "/services/artcontract/sculpture", "name":"Sculpture", "image_url":"https://all-about-images.s3.us-east-2.amazonaws.com/Home_Gallery/r4c2.jpg"},
    // {"goto": "/comingsoon", "name":"Craft", "image_url":"https://all-about-images.s3.us-east-2.amazonaws.com/Home_Gallery/r4c3.jpg"}
]

export const HomeVideo= ["wmLqkwgVFTk","OSo3N8aMZlM", "UkI989GxNfY","6jVINZF33i4"]

export const ArtContractSubParts=
{
    "Portrait": {
        "artist":"Artist",
        "classes":"col-lg-3 col-md-6 p-1 order-md-5", 
        "pathway": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/ArtContract/Portrait/",
        "heading": "Portrait",
        "artistImage1":"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Artist/lokesh.jpg",
        "artistName1": "Lokesh nayak",
        "artistDegree1":"BFA Painting",
        "artistImage2":"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Artist/nutun.jpg",
        "artistName2": "Nutan Kishore Nishad",
        "artistDegree2":"BFA MFA Graphics",
        "content":["Pencil","Oil","Water Colour","Digital"],
        "work":["wportrait2.jpg","wportrait3.jpg","wportrait1.jpg","wportrait6.jpg","dportrait10.jpg","dportrait2.jpg","dportrait3.jpg","dportrait4.jpg","dportrait5.jpg","dportrait11.jpg","dportrait7.jpg","dportrait8.jpg"] 
    },
    "Rangoli": {
        "artist":"Artist",
        "classes":"col-sm-6 p-1", 
        "pathway": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/ArtContract/Rangoli/",
        "heading": "Rangoli",
        "artistImage":"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Artist/prabhat.jpg",
        "artistName": "Prabhat Barmaiya",
        "artistDegree":"BFA MFA Painting",
        "content":["Realsize","Hyper RealSize","Festive", "Your Choice"],
        "work":["rangoli1.jpg","rangoli2.jpg","rangoli3.jpg","rangoli4.jpg","rangoli5.jpg","rangoli6.jpg"] 
    },
    "WallPainting": {
        "artist":"Artist",
        "classes":"col-sm-6 p-1",
        "pathway": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/ArtContract/WallPainting/", 
        "heading": "Wall Painting",
        "artistImage":"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Artist/siddhant.jpg",
        "artistName": "Siddhant Singh Baghel",
        "artistDegree":"BFA MFA Painting",
        "content":["2d & 3d Art","Folkart","Government Project","Private Project","Tourism"],
        "work":["wallpainting1.jpg","wallpainting2.jpg","wallpainting3.jpg","wallpainting5.jpg","wallpainting6.jpg","wallpainting7.jpg","wallpainting8.jpg","wallpainting9.jpg","wallpainting11.jpg","wallpainting12.jpg"] 

    },
    "Landscape": {
        "artist":"Artist",
        "classes":"col-md-6 p-1",
        "pathway": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/ArtContract/Landscape/", 
        "heading": "Landscape",
        "artistImage":"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Artist/prabhat.jpg",
        "artistName": "Prabhat Barmaiya",
        "artistDegree":"BFA MFA Painting",
        "content":["Oil","Acrylic","Pencil", "pen","Water Colour"],
        "work":["landscape1.jpg","landscape2.jpg","landscape3.jpg","landscape4.jpg","landscape10.jpg","landscape6.jpg","landscape7.jpg","landscape8.jpg"] 
    },
    "Sculpture": {
        "artist":"Artist",
        "classes":"col-md-6 p-1",
        "pathway": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/ArtContract/Sculpture/", 
        "heading": "Sculpture",
        "artistImage":"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Artist/arvind.jpg",
        "artistName": "Arvind Prajapati",
        "artistDegree":"BFA MFA Sculpture",
        "content":["Life Size Sculpture","Relief Work","Portrait Sculpture"],
        "work":["sculpture1.jpg","sculpture2.jpg","sculpture3.jpg","sculpture4.jpg","sculpture5.jpg","sculpture6.jpg","sculpture7.jpg","sculpture8.jpg"] 
    },
    "Tattoo": {
        "artist":"Artist",
        "classes":"col-md-6 p-1 order-md-5",
        "pathway": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/ArtContract/Tattoo/", 
        "heading": "Tattoo",
        "artistImage1":"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Artist/dibakar.jpg",
        "artistName1": "Dibakar Bala",
        "artistDegree1":"BFA MFA Painting",
        "artistImage2":"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Artist/nagendra.jpg",
        "artistName2": "Nagendra sahu",
        "artistDegree2":"B.Voc Designing",
        "content":["Choose Your Style"],
        "work":["tattoo1.jpg","tattoo2.jpg","tattoo3.jpg","tattoo4.jpg","tattoo5.jpg","tattoo6.jpg","tattoo7.jpg","tattoo8.jpg"] 
    },
    "Architect": {
        "artist":"Artist",
        "classes":"col-md-6 p-3",
        "pathway": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Architect/", 
        "heading": "Architect",
        "artistImage":"https://all-about-images.s3.us-east-2.amazonaws.com/Team/prince.jpg",
        "artistName": "Prince Patel",
        "artistDegree":"NIT Nagpur (B.Arch)",
        "content":["RESIDENTIAL", "CULTURE & MUSEUM","EDUCATION & SPORTS","HOSPITALITY", "MIXED USE & RETAIL", "SCIENCE & TECH"],
        "work":["architect1.jpg","architect2.jpg"],
        "video":["EyrWz4mzLt4","ij1BQGZjzQw","lJoN7TYnX9o","ZO4-sNEJh-M"]  
    },
    "Interior": {
        "artist":"Artist",
        "classes":"col-md-6 p-3",
        "pathway": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Architect/", 
        "heading": "Interior Design",
        "artistImage":"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Artist/arnab.jpg",
        "artistName": "ARNAB MONDAL",
        "artistDegree":"B.Arch",
        "content":["RESIDENTIAL", "CULTURE & MUSEUM","EDUCATION & SPORTS","HOSPITALITY", "MIXED USE & RETAIL", "SCIENCE & TECH"],
        "work":["interior1.jpg","interior2.jpg","interior3.jpg","interior4.jpg","interior5.jpg","interior6.jpg",
        "interior7.jpg","interior8.jpg","interior9.jpg","interior10.jpg","interior11.jpg","interior12.jpg",
        "interior13.jpg","interior14.jpg","interior15.jpg","interior16.jpg","interior17.jpg","interior18.jpg"] 
    },
    "Gazal": {
        "artist":"Artist",
        "classes":"col-md-6 p-1 order-md-5", 
        "pathway": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Occassion/Gazal/",
        "heading": "Ghazal night",
        "artistImage1":"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Artist/sweta.jpg",
        "artistName1": "Sweta Dev",
        "artistDegree1":"B.A, M.A Vocal & Diploma in Light Music",
        "artistImage2":"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Artist/sugam.jpg",
        "artistName2": "Sugam shiwale",
        "artistDegree2":"B.A, M.A Vocal & Diploma in Light Music",
        "content":["Southe your soul by","Remembering legendary voices"],
        "work":["gazal1.jpg","gazal2.jpg","gazal3.jpg","gazal4.jpg","gazal5.jpg"],
        "video":["Y9oK_PiXghQ", "LCaLj8Euj6Y","UkI989GxNfY","LmtJYrLnXgE","B5q1-5oXTaI"]  

    },
    "Suffi": {
        "artist":"Artist",
        "classes":"col-md-6 p-3",
        "pathway": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Occassion/Suffi/", 
        "heading": "Light Music & sufi night",
        "artistImage":"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Artist/narindra.jpg",
        "artistName": "Narindra Singh Pal",
        "content":["Live your inner soul"],
        "work":["suffi1.jpg","suffi2.jpg","suffi3.jpg","suffi4.jpg","suffi5.jpg","suffi6.jpg"],
        "video":["Cqh9wOswWMw","UvBnmB48-M8","hIxLJbiphUQ","bTYjBiw8stE"]  
 
    },
    "Devotional": {
        "artist":"Artist",
        "classes":"col-md-6 p-3 order-md-5",
        "pathway": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Occassion/Devotional/", 
        "heading": "Devotional",
        "artistImage1":"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Artist/narindra.jpg",
        "artistName1": "Narindra Singh Pal",
        "artistImage2":"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Artist/kanchan.jpg",
        "artistName2": "Kanchan Vishavkarma",
        "artistDegree2":"B.A Vocal Music",
        "content":["Jagrata","Bhajan sandhya"],
        "work":["devotional1.jpg","devotional2.jpg","devotional3.jpg","devotional4.jpg","devotional5.jpg","devotional6.jpg"],
        "video":["JWt5aly7eOQ","gqXIkp3tepw"]  
 
    },
    "Instrumental": {
        "artist":"Artist",
        "classes":"col-md-6 p-3 order-md-5",
        "pathway": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Occassion/Instrumental/", 
        "heading": "Instrumental & Orchestra",
        "artistImage1":"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Artist/rajveer.jpg",
        "artistName1": "Rajveer vishvkarma",
        "artistImage2":"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Artist/raja.jpg",
        "artistName2": "Raja banshkar",
        "content":["Tabla","Guitar", "Saxophone", "Flute", "Voilin"],
        "work":["instrumental1.jpg","instrumental2.jpg"],
        "video":["WWTrH0AXEjQ","41gom-OoNaI"]  
 
    },
    "Band": {
        "artist":"Artist",
        "classes":"col-md-6 p-3",
        "pathway": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Occassion/Band/", 
        "heading": "Bollywood Band",
        "artistImage":"https://all-about-images.s3.us-east-2.amazonaws.com/Service/Artist/swapneel.jpg",
        "artistName": "Swapneel jaiswal",
        "artistDegree":"B.A Vocal Music",
        "content":["UNPLUGGED","BOLLYWOOD","SOFT ROMANTIC","DANCE NUMBER","INDI-POP","5 PIECE BAND","3 PIECE BAND"],
        "work":["band1.jpg","band2.jpg","band3.jpg","band4.jpg","band5.jpg","band6.jpg"],
        "video":["-k-8ikT4K8U","x6B1Vb_pIC8","7nbeiDDaDP0","30xcqKXtBuw"]  
    },
    "ClassicalDance": {
        "classes":"col-md-6 p-3 order-md-5",
        "pathway": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Occassion/Classical/", 
        "heading": "Classical Dance",
        "content":["Kathak","Odishi","Kathakkali","Bharatnatyam"],
        "work":["classical1.jpg","classical2.jpg","classical3.jpg","classical4.jpg","classical5.jpg","classical6.jpg"],
        "video":["CrASOe94Y3E","rEu0eJU66Qo"]  
    },
    "Western": {
        "classes":"col-md-6 p-3 order-md-5",
        "pathway": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Occassion/Western/", 
        "heading": "Western & Bollywood Dance",
        "content":["Freestyle Bollywood","Contemporary","Hip Hop","Break Dance", "Salsa"],
        "work":["western1.jpg","western2.jpg"],
        "video":["sJq3HXc4XAE", "OSo3N8aMZlM", "Kgq1kjnr7tc", "vaCpT7oamCg"]  
    },
    "Folk": {
        "classes":"col-md-6 p-3 order-md-5",
        "pathway": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Occassion/Folk/", 
        "heading": "Folk Dance",
        "content":["Bihu","Garba","Raut Nacha","Ghumar","Karma","Bhangra","Kalbeliya","Panthi"],
        "work":["folk1.jpg","folk2.jpg","folk3.jpg","folk4.jpg","folk5.jpg","folk6.jpg"],
        "video":["v1lSh9W4bfQ", "bemepZc1JtI", "CqntSjkSJO0", "uBvFF7yT0fE"]  
    }
}



export const HomeSlider=[
    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Slider/slider3.jpg"},
    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Slider/slider2.jpg"},
    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/Slider/slider1.jpg"}
]

export const WeddingCard=[

    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/WeddingCard/weddingCard1.jpg", "name": "Creative"},
    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/WeddingCard/weddingCard2.jpg", "name": "Royal"},
    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/WeddingCard/weddingCard3.jpg", "name": "Harry Potter"},
    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/WeddingCard/weddingCard4.jpg", "name": "Artistic"}

]

export const StageDecoration=[
    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/StageDecoration/stageDecoration1.jpg"},
    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/StageDecoration/stageDecoration2.jpg"},
    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/StageDecoration/stageDecoration3.jpg"},
    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/StageDecoration/stageDecoration4.jpg"},
    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/StageDecoration/stageDecoration5.jpg"},
    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/Wedding/StageDecoration/stageDecoration6.jpg"}
]

export const ArtContractData=[
    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/ArtContract/portrait.jpg", "path": "/services/artcontract/portrait", "name": "Portrait"},
    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/ArtContract/tattoo.jpg", "path": "/services/artcontract/tattoo", "name": "Tattoo"},
    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/ArtContract/sculpture.jpg", "path": "/services/artcontract/sculpture", "name": "Sculpture"},
    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/ArtContract/rangoli.jpg", "path": "/services/artcontract/rangoli", "name": "Rangoli"},
    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/ArtContract/wallpainting.jpg", "path": "/services/artcontract/wallpainting", "name": "Wall Painting"},
    {"img": "https://all-about-images.s3.us-east-2.amazonaws.com/Service/ArtContract/landscape.jpg", "path": "/services/artcontract/landscape", "name": "Landscape"}
]


export const Demo = [
    { id: "1", tag:"marriage",  url: "https://source.unsplash.com/Dm-qxdynoEc/800x799"},
    { id: "2", tag:"marriage",  url: "https://source.unsplash.com/Dm-qxdynoEc/800x799"},
    { id: "3", tag:"marriage",  url: "https://source.unsplash.com/qDkso9nvCg0/600x799"},
    { id: "4", tag:"marriage",  url: "https://source.unsplash.com/iecJiKe_RNg/600x799"},
    { id: "5", tag:"marriage",  url: "https://source.unsplash.com/epcsn8Ed8kY/600x799"},
    { id: "6", tag:"occasion",  url: "https://source.unsplash.com/NQSWvyVRIJk/800x599"},
    { id: "7", tag:"occasion",  url: "https://source.unsplash.com/zh7GEuORbUw/600x799"},
    { id: "8", tag:"occasion",  url: "https://source.unsplash.com/PpOHJezOalU/800x599"},
    { id: "9", tag:"occasion",  url: "https://source.unsplash.com/I1ASdgphUH4/800x599"},
    { id: "10", tag:"event",  url: "https://source.unsplash.com/XiDA78wAZVw/600x799"},
    { id: "11", tag:"event",  url: "https://source.unsplash.com/x8xJpClTvR0/800x599"},
    { id: "12", tag:"event",  url: "https://source.unsplash.com/u9cG4cuJ6bU/927x1000"},
    { id: "13", tag:"art",  url: "https://source.unsplash.com/qGQNmBE7mYw/800x599"},
    { id: "14", tag:"art",  url: "https://source.unsplash.com/NuO6iTBkHxE/800x599"},
    { id: "15", tag:"art",  url: "https://source.unsplash.com/pF1ug8ysTtY/600x400"},
    { id: "16", tag:"art",  url: "https://source.unsplash.com/A-fubu9QJxE/800x533"},
    { id: "17", tag:"art",  url: "https://source.unsplash.com/5P91SF0zNsI/740x494"}
];